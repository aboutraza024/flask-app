from flask import Flask, render_template, request, flash

import cv2
import os
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'C:\\Users\\hp\\PycharmProjects\\imageapp\\uploadfiles'
ALLOWED_EXTENSIONS = {'webp', 'grayscale', 'png', 'jpg', 'jpeg', 'gif'}

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def img_process(filename, Operation):
    print(f"the operation is {Operation} and filename is {filename}")
    img = cv2.imread(f"C:\\Users\\hp\\PycharmProjects\\imageapp\\uploadfiles\\{filename}")
    imgpr = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if Operation == "cgray":
        imgpr = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        cv2.imwrite(f"C:\\Users\\hp\\PycharmProjects\\imageapp\\static\\{filename}", imgpr)
        return filename
    if Operation == "cwebg":
        cv2.imwrite(f"C:\\Users\\hp\\PycharmProjects\\imageapp\\static\\{filename.split('.')[0]}.webp", imgpr)
        return filename
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/documentation")
def Documentation():
    return render_template("Documentation.html")


@app.route("/about")
def About():
    return render_template("About.html")


@app.route("/contact")
def Contact():
    return render_template("Contact.html")


@app.route("/edit", methods=["GET", "POST"])
def edit():
    if request.method == 'POST':
        operation = request.form.get('Operation')
        filename = request.form.get('filename')
        print(filename)
        if 'file' not in request.files:
            flash('No file part')
            return "FILE IS NOT REQUESTED"
    file = request.files['file']

    if file.filename == '':
        flash('No selected file')
        return "NO FILE SELECTED"
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        img_process(filename, operation)
        flash(f"YOU IMAGE HAS BEEN AND IS AVAILABLE <a href='\static\{filename}' target='_blank'>HERE</a>")
        return render_template("index.html")
    return render_template("index.html")


app.run(debug=True, port=5001)
