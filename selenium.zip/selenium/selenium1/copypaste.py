from selenium import webdriver
from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("https://text-compare.com/")
driver.maximize_window()
input1 = driver.find_element(By.XPATH, "//textarea[@id='inputText1']")
input1.send_keys("hlo jni")
#input2 = driver.find_element(By.XPATH, "//textarea[@id='inputText2']")
#act = ActionChains(driver)
# performing control a for selecting all data
#act.key_down(Keys.CONTROL)    #press the CTRl
#act.send_keys("a")             #send a
#act.key_up(Keys.CONTROL)       # release CTRL
#act.perform()
#time.sleep(1)
# ctrl c
#act.key_down(Keys.CONTROL).send_keys("c").key_up(Keys.CONTROL).perform()  # this will copy text
#time.sleep(1)
# move second box by pressing tab key
#act.send_keys(Keys.TAB).perform()

# now press ctrl v
#act.key_down(Keys.CONTROL).send_keys("v").key_up(Keys.CONTROL).perform()




time.sleep(2)
