import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("https://itera-qa.azurewebsites.net/home/automation")
# driver.find_element(By.XPATH, "//*[@id='monday']").click()  for selecting 1 checkbox

k1 = driver.find_elements(By.XPATH, "//input[@type='checkbox' and contains(@id,'day')]")  # selecting all check boxes
print(len(k1))
# for i in range(len(k1)):
# k1[i].click()
# SELECT CHECKBOX ACCORDING TO YOUR CHOICEs
#for i in range(len(k1)-5):
    #k1[i].click()

for i in range(len(k1)):
    k1[i].click()

time.sleep(6)
