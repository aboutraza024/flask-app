import  time
from selenium import webdriver
from selenium.webdriver.chrome import Chrome
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.support.select import Select

def fiver():
    driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
    driver.get("https://www.fiverr.com/categories/graphics-design?source=category_tree")
    driver.maximize_window()
    input= driver.find_element(By.XPATH, "//input[@placeholder='What service are you looking for today?']")
    input.send_keys("website automation")
    search=driver.find_element(By.XPATH, "//button[@class='FW1syM7 L1yjt43 co-white submit-button dark-search-button bg-co-green-700']")
    search.click()
    time.sleep(10)


def chatgpt():
     driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
     driver.get("https://poe.com/")
     

     time.sleep(10)



chatgpt()
