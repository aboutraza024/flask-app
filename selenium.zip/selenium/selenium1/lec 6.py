from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service

driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("https://www.google.com/")
driver.find_element(By.XPATH, "//*[@id='input']").send_keys("selenium")
driver.find_element(By.XPATH, "//*[@id='input']").submit()
