#mouse hover
import time
from selenium import webdriver
#from selenium.webdriver.chrome.select import Select
from selenium.webdriver.support.select import Select
from selenium.webdriver.chrome import Chrome
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service

import time

from selenium1.elements import element

driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("https://cms.bahria.edu.pk/Logins/Student/Login.aspx")
driver.find_element(By.XPATH, "//input[@ name='ctl00$BodyPH$tbEnrollment']").send_keys("01-134222-185")
driver.find_element(By.XPATH, "//input[@ placeholder='Password']").send_keys("matric73%")
driver.find_element(By.XPATH, "//*[@id='BodyPH_ddlInstituteID']").send_keys("Islamabad Campus")
driver.find_element(By.XPATH, "//a[@ data-validationgroup='Login']").click()
driver.maximize_window()
#time.sleep(3)
href = driver.find_element(By.XPATH, "//*[@id='sideMenuList']/a[15]").get_attribute('href')
driver.get(href)

time.sleep(3)

