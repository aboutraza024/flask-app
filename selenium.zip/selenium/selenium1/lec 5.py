import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("https://cms.bahria.edu.pk/")
driver.get("https://www.programiz.com/cpp-programming/online-compiler/") # Correctly locate the link by its URL
driver.back()
driver.forward()
#driver.reload()
time.sleep(3)
driver.close()
