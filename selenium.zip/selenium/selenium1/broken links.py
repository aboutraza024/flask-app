# we need to install the request library
import time
import requests as requests
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("http://www.deadlinkcity.com/")
driver.maximize_window()
alllinks=driver.find_elements(By.TAG_NAME,"a")
count=0
for link in alllinks:
    url=link.get_attribute('href')
    try:
        res=requests.head(url)
    except:
        None
    #print(res)
    if res.status_code>=400:
        print(url,"broken link")
        count=count+1
    else:
        print(url,"valid link")

print("total b links",count)

print(url)
time.sleep(1)

