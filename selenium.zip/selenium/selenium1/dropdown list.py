import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("https://cms.bahria.edu.pk/Logins/Student/Login.aspx")
driver.maximize_window()
dropdown = driver.find_element(By.XPATH, "//*[@id='BodyPH_ddlInstituteID']")
s1 = Select(dropdown)

# select option from drop down
#s1.select_by_visible_text("Islamabad Campus")
#s1.select_by_value("6")    #method 2
#s1.select_by_index(5)     #method 3

#capture all options
#alloptions=s1.options
#print(len(alloptions))
#for i in alloptions:
 #   print(i.text)

 #without using the built in function select from dropdown

for opt in s1.options:
    if opt.text=="Lahore Campus":
        opt.click()
time.sleep(10)
