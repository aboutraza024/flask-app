#mouse hover

from selenium import webdriver
from selenium.webdriver import ActionChains

from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service

import time
driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
#driver.get('https://swisnl.github.io/jQuery-contextMenu/demo.html')
#button = driver.find_element(By.XPATH, "//span[@class='context-menu-one btn btn-neutral']")
#act = ActionChains(driver)
#act.context_click(button).perform()
 #drag and drop
#driver.get('http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html')
#s1 = driver.find_element(By.ID, "box6")
#p1 = driver.find_element(By.ID, "box106")
#act = ActionChains(driver)
#act.drag_and_drop(s1,p1).perform()


driver.get("https://jqueryui.com/resources/demos/slider/range.html")
st_val= driver.find_element(By.XPATH, "//*[@id='slider-range']/span[1]")

lt_val= driver.find_element(By.XPATH,"//*[@id='slider-range']/span[2]")

print(st_val.location)
print(lt_val.location)
time.sleep(4)

