from selenium import webdriver
from selenium.webdriver.chrome.service import Service
import time
driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("https://cms.bahria.edu.pk/")
time.sleep(10)

# Close the browser window
driver.quit()
