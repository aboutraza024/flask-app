from selenium import webdriver
import time
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("https://file-examples.com/index.php/sample-documents-download/")
time.sleep(10)
driver.find_element(By.XPATH, "//*[@id='table-files']/tbody/tr[1]/td[5]/a[1]").click()
time.sleep(2)
