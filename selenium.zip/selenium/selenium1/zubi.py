from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
import time
driver = webdriver.Chrome(service=Service("D:/selenium drivers/chromedriver_win32/chromedriver.exe"))
driver.implicitly_wait(10)
driver.get("https://www.dummyticket.com/dummy-ticket-for-visa-application/")
driver.find_element(By.XPATH, "//*[@id='select2-billing_country-container']").click()
l1=driver.find_elements(By.XPATH, "//ul[@id='select2-billing_country-results']/li")
l2=len(l1)
print(l2)
for l3 in l1:
    if l3.text=="pakistan":
        l3.click()
        break

time.sleep(9)

















time.sleep(10)
