from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
import time

preferences = {"download.default_directory": r"C:\Users\hp\Desktop\UNIVERSITY",}
ops = webdriver.ChromeOptions()
ops.add_experimental_option("prefs", preferences)
driver = webdriver.Chrome(service=Service("D:/selenium drivers/chromedriver_win32/chromedriver.exe"),options=ops)
driver.get("https://docs.google.com/viewer?a=v&pid=sites&srcid=aWVtY2FsLmNvbXxwcGwtd2l0aC1jfGd4OjRkOWI2YWYzODA2MmYzZTQ")
driver.find_element(By.XPATH, "/html/body/div[2]/div[4]/div/div[3]/div[2]/div[2]/div[2]").click()
time.sleep(15)
