import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("https://cms.bahria.edu.pk/Logins/Student/Login.aspx")
element = driver.find_element(By.XPATH,"//*[@id='brandShortName']")
print(element.text)
#print(element.get_attribute('value'))
time.sleep(8)
