from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common import keys
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
import time
driver = webdriver.Chrome(service=Service("D:/selenium drivers/chromedriver_win32/chromedriver.exe"))
driver.implicitly_wait(10)
driver.get("https://demo.nopcommerce.com/register?returnUrl=%2F")
driver.switch_to.new_window("window")
driver.get("https://demo.nopcommerce.com/computers")
time.sleep(10)
