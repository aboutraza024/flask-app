from selenium import webdriver

from selenium.webdriver.chrome.service import Service
import time

driver = webdriver.Chrome(service=Service("D:/selenium drivers/chromedriver_win32/chromedriver.exe"))
driver.implicitly_wait(10)
driver.get("https://www.nopcommerce.com/en")
c1 = driver.get_cookies()
print("first all cookie",len(c1))
# for c in c1:
# print(c.get('name'),":",c.get('value'))
# adding cookies
driver.add_cookie({"name": "mian", "value": "shezada"})
c1 = driver.get_cookies()
print("add cookies",len(c1))
driver.delete_cookie("mian")
c1 = driver.get_cookies()
print("delete sepecfied  cookies",len(c1))
# delete all cookies
driver.delete_all_cookies()
c1 = driver.get_cookies()
print("delete all cookies",len(c1))
time.sleep(2)
