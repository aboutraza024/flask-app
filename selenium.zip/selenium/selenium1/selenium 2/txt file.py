# read data
path = "C:\\Users\\hp\\Desktop\\python\\files in python.txt"
with open(path,"r") as file:
    line=file.readlines()
for lines in line:
    print(lines)
# write data

path = "C:\\Users\\hp\Desktop\\name.txt"
with open(path,"w") as file:
    file.write("dilll da ni mara tera mian narowal ala ")
