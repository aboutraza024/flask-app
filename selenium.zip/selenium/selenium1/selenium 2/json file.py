import json

path = 'json file.json'

with open('json file.json', 'r') as file:
    data = json.load(file)
    print(data)
