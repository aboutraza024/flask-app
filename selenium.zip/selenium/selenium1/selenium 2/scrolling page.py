from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("https://www.worldometers.info/geography/flags-of-the-world/")

# Scroll by pixels
#driver.execute_script("window.scrollBy(0, 2500)")

# Wait for the scroll to take effect (you may adjust this time as needed)
#time.sleep(3)

# Get the number of pixels scrolled in the vertical direction
#value = driver.execute_script("return window.pageYOffset;")
#print("number of pixels:", value)

# now second method finding pakistan flag
#flag=driver.find_element(By.XPATH, "//img[@src='/img/flags/small/tn_pk-flag.gif']")
#driver.execute_script("arguments[0].scrollIntoView();", flag)
#value=driver.execute_script("return window.pageYOffset;")
#print("numb of pix",value)

#go at the end of the page
driver.execute_script("window.scrollTo(0,document.body.scrollHeight)")
value=driver.execute_script("return window.pageYOffset;")
print("numb of pix",value)

#driver.execute_script("window.scrollBy(0,-document.body.scrollheight)")
#value=driver.execute_script("return window.pageYOffset;")
#print("numb of pix",value)
time.sleep(2)
driver.quit()


