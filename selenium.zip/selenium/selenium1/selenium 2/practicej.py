import json

# reading data from file
# with open("practj.json",'r')as json_file:
#   data=json.load(json_file)

# acess values using keys      print(data['name'])
# print(data['age'])
# print(data['hobbies'])
# print(data)                 # acessing all data

# NOW WRITE DATA IN FILE

print("\nNOW WRITE DATA IN FILE\n")
data = {"raza": "mehar", "buic": "sem2"}
with open("practj.json", "w") as json_file:
    json.dump(data, json_file, indent=6)  # write data in file

print("\nSTART UPDATING DATA\n")

data['raza'] = "ali"
data['buic'] = "bulc"
with open("practj.json", "w") as json_file:
    json.dump(data, json_file, indent=12)  # updating data
print("deleting data")
if 'raza' in data:
    del data['raza']
with open("practj.json","w"):
    json.dump(data,json_file,indent=4)



