import configparser
path = "new.ini"
con = configparser.ConfigParser()
# reading data from the file

with open(path, "r") as config:
    con.read(path)
    print(con.sections())  # is used to show all sections in file
    print(con['account'])  # is used to show only one section which is account
    print(list(con['account']))  # display all keys
    print(list(con['account']['name']))  # display the value of name

# writing data in the file

con.add_section('bank')
con.set('bank', 'HBL', "mera account")
with open(path, "w") as file1config:
    con.write(file1config)

print("section added")
