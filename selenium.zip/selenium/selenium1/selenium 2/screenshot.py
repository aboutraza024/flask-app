from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
import time
driver = webdriver.Chrome(service=Service("D:/selenium drivers/chromedriver_win32/chromedriver.exe"))
driver.implicitly_wait(10)
driver.get("https://www.nopcommerce.com/en/demo")
driver.maximize_window()
driver.save_screenshot("C:\\Users\\hp\Desktop\\UNIVERSITY\\ss.png")
driver.quit()
