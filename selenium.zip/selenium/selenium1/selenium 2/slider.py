from selenium import webdriver
from selenium.webdriver import ActionChains

from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
import time
driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("https://jqueryui.com/resources/demos/slider/range.html")
st_val= driver.find_element(By.XPATH, "//*[@id='slider-range']/span[1]")

lt_val= driver.find_element(By.XPATH,"//*[@id='slider-range']/span[2]")

print(st_val.location)
print(lt_val.location)
act=ActionChains(driver)
act.drag_and_drop_by_offset(st_val,300,0).perform()
act.drag_and_drop_by_offset(lt_val,-30,0).perform()
print("after changing slider")
print(st_val.location)
print(lt_val. location)
time.sleep(4)
