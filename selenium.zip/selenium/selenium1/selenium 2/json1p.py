import json

# Assuming you have a JSON file named 'data.json'
with open('file.json', 'r') as json_file:
    data = json.load(json_file)

print(data)
