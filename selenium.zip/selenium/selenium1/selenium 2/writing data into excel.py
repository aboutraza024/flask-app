import openpyxl

path = "C:\\Users\\hp\Desktop\\22.xlsx"
workbook=openpyxl.load_workbook(path)
sheet=workbook.active
# active current file  for writing

for r in range(1,5):
    for c in range(1,4):
        print("Row number:",r,"column number",c)
        m=input("enter value")
        sheet.cell(r,c).value = m

workbook.save(path)
