from selenium import webdriver
import time

from selenium.webdriver.chrome.service import Service

# Initialize Chrome WebDriver with headless mode using options parameter
ops = webdriver.ChromeOptions()
ops.add_argument('--headless')



# Initialize Chrome WebDriver
driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"),
                          options=ops)

# Now you can use the driver to perform actions on web pages without a visible browser window.

# Example: Open a website
driver.get("https://cms.bahria.edu.pk/Logins/Student/Login.aspx")
print(driver.title)
print(driver.current_url)

time.sleep(4)

# Don't forget to close the browser when you're done.
driver.quit()
