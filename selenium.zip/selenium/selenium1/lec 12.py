from selenium import webdriver
import time
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("https://cms.bahria.edu.pk/Logins/Student/Login.aspx")
driver.find_element(By.XPATH, "//input[@ name='ctl00$BodyPH$tbEnrollment']").send_keys("01-134222-185")
driver.find_element(By.XPATH, "//input[@ placeholder='Password']").send_keys("matric73%")
driver.find_element(By.XPATH, "//*[@id='BodyPH_ddlInstituteID']").send_keys("Islamabad Campus")
driver.find_element(By.XPATH, "//a[@ data-validationgroup='Login']").click()
driver.maximize_window()
# time.sleep(3)
href = driver.find_element(By.XPATH, "//*[@id='sideMenuList']/a[15]").get_attribute('href')
driver.get(href)
s1 = driver.find_element(By.XPATH, "//*[@id='semesterId']")
s2 = Select(s1)
s2.select_by_visible_text("Spring-2023")
print("what you want to download:")
print(
    "COURSE OUTLINE\nCOURSE PLAN\nASSIGNMENTS\nLECTURES\nQUIZ\nMISCLLINOUS\nPAPERS\nANNOUNCMENTS\nGUIDELINES\nONLINE LIBRARIES\nFAQS")
num = input("CHOOSE ANYONE\n")
if num == "COURSE OUTLINE" or num == "course outline":
    driver.find_element(By.XPATH, "//*[text()='Course Outline']").click()
    driver.find_element(By.XPATH, "//*[@id='semesterId']")
    s1 = driver.find_element(By.XPATH, "//*[@id='semesterId']")
    s2 = Select(s1)
    s2.select_by_visible_text("Spring-2023")
elif num == "course plan" or num == "COURSE PLAN":
    driver.find_element(By.XPATH, "//*[text()='Course Plan']").click()
    s1 = driver.find_element(By.XPATH, "//*[@id='semesterId']")
    s2 = Select(s1)
    s2.select_by_visible_text("Spring-2023")
    s3 = driver.find_element(By.XPATH, "//*[@id='courseId']")
    s4 = Select(s3)
    num1 = input("ENTER COURSE NAME")
    s4.select_by_visible_text(num1)
elif num == "lecture note" or num == "LECTURE NOTE":
    driver.find_element(By.XPATH, "//*[text()='Lecture Notes']").click()
    s1 = driver.find_element(By.XPATH, "//*[@id='semesterId']")
    s2 = Select(s1)
    s2.select_by_visible_text("Spring-2023")
    s5 = driver.find_element(By.XPATH, "//*[@id='courseId']")
    s6 = Select(s5)
    num3 = input("ENTER COURSE:")
    s6.select_by_visible_text(num3)
    time.sleep(3)
    elements=driver.find_elements(By.XPATH, "//a[@class='label label-info']")  # DOWNLOAD ALL LECTURES
    for element in elements:
        element.click()
elif num == "assignment" or num == "ASSIGNMENT":
    driver.find_element(By.XPATH, "//*[text()='Assignments']").click()
    s1 = driver.find_element(By.XPATH, "//*[@id='semesterId']")
    s2 = Select(s1)
    s2.select_by_visible_text("Spring-2023")
    s5 = driver.find_element(By.XPATH, "//*[@id='courseId']")
    s6 = Select(s5)
    num4 = input("ENTER COURSE:")
    s6.select_by_visible_text(num4)
    elements=driver.find_elements(By.XPATH, "//a[@class='label label-info']")
    for element in elements:
        element.click()
time.sleep(30)
driver.quit()
