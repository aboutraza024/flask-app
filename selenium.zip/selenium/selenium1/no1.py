# selenium lecture no 2
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium1.delays import Delay
num = input("enter any thing for search on gpt and press escape key")
delay = Delay()
delay.escape_pressed()
driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.maximize_window()
driver.get("https://chat.openai.com/")
driver.find_element(By.XPATH, "/html/body/div[1]/div[1]/div[1]/div[4]/button[1]/div").click()

#driver.find_element(By.XPATH,"/html/body/table/tbody/tr/td/div/div[1]/table/tbody/tr/td[1]/div[1]/div/label/span[1]").click()
driver.find_element(By.XPATH,"/html/body/div/main/section/div/div/div/div[1]/div/form/div[1]/div/div/div/input").clear()
driver.find_element(By.XPATH,"/html/body/div/main/section/div/div/div/div[1]/div/form/div[1]/div/div/div/input").\
    send_keys("aboutraza024@gmail.com")
driver.find_element(By.XPATH,"/html/body/div[1]/div[1]/div/div/main/div[2]/form/div/div[1]/button/span/svg/path").click()
driver.find_element("/html/body/div/main/section/div/div/div/div[1]/div/form/div[2]/button").click()
driver.find_element("/html/body/div/main/section/div/div/div/form/div[2]/div/div[2]/div/input").clear()
driver.find_element("/html/body/div/main/section/div/div/div/form/div[2]/div/div[2]/div/input").send_keys("matric73%")
driver.find_element(By.XPATH,"/html/body/div[1]/div[1]/div/div/main/div[2]/form/div/div[1]/button/span/svg/path").click()
driver.find_element(By.XPATH, "/html/body/div[1]/div[1]/div/div/main/div[2]/form/div/div/textarea").send_keys(num)
driver.find_element(By.XPATH,"/html/body/div[1]/div[1]/div/div/main/div[2]/form/div/div/button")

