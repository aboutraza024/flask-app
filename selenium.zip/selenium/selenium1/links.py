import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

driver = webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
driver.get("https://www.nopcommerce.com/en")

# Uncomment and correct the XPath if needed
# driver.find_element(By.XPATH, "//*[@id='en-page']/body/div[7]/section/div/div"
#                               "/div/div/div/div/div[1]/div/div[1]/div/a[2]").click()

# Find all links on the page
links = driver.find_elements(By.TAG_NAME, "a")
print(len(links))

for link in links:
    print(link.text)

time.sleep(1)

# Remember to close the browser when done
driver.quit()
