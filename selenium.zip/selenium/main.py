# first day selenium    and buic login test
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
#import time
from selenium1.delays import Delay

from selenium.webdriver.common.by import By
delay = Delay()

driver=webdriver.Chrome(service=Service("D:\selenium drivers\chromedriver_win32\chromedriver.exe"))
#driver=webdriver.Chrome()
driver.get("https://cms.bahria.edu.pk/Logins/Student/Login.aspx")
print(driver.title)
print(driver.current_url)
#print(driver.page_source)
driver.find_element(By.XPATH,"/html/body/form/div[3]/div/div[2]/div[2]/div/div[2]/div/input").\
    send_keys("01-134222-185")

driver.find_element(By.XPATH,"/html/body/form/div[3]/div/div[2]/div[2]/div/div[3]/div/input").\
    send_keys("matric73%")
driver.find_element(By.XPATH,"/html/body/form/div[3]/div/div[2]/div[2]/div/div[4]/div/select").\
    send_keys("Islamabad Campus")
driver.find_element(By.XPATH,"/html/body/form/div[3]/div/div[2]/div[2]/div/div[5]/div/select").\
    send_keys("Islamabad Campus")
driver.find_element(By.XPATH,"/html/body/form/div[3]/div/div[2]/div[2]/div/div[6]/a").click()
v1=driver.title
v2="Dashboard - Bahria University"
if v1==v2:
    print("\n\n\nlogin sucssesfully")
else:
    print("unknown error occur")

driver.quit()
