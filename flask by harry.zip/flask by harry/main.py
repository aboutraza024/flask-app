import os.path
import os
from flask import Flask, render_template, request, session,redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask_mail import Mail
from flask_mail import Message
from flask_session import Session
import json
import math
from werkzeug.utils import secure_filename
with open("config.json", "r") as c:
    data = json.load(c)
    params = data["params"]

local_server = True

app = Flask(__name__)
app.secret_key = "your_secret_key_here"
app.config["UPLOAD_FOLDER"] = params["upload_location"]
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

app.config.update(
    MAIL_SERVER="smtp.gmail.com",
    MAIL_PORT="465",
    MAIL_USE_SSL=True,
    MAIL_USERNAME=params['user_name'],
    MAIL_PASSWORD=params['user_password']
)
mail = Mail(app)

if local_server:
    app.config["SQLALCHEMY_DATABASE_URI"] = params["local_uri"]
else:
    app.config["SQLALCHEMY_DATABASE_URI"] = params["prod_uri"]

db = SQLAlchemy(app)

class Contacts(db.Model):
    sr = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(40), nullable=True)
    phone_number = db.Column(db.String(12), nullable=False)
    message = db.Column(db.String(50), nullable=False)
    date = db.Column(db.DateTime, nullable=True, default=datetime.utcnow)

class Posts(db.Model):
    SN0 = db.Column(db.Integer, primary_key=True)
    Title = db.Column(db.String(50), nullable=False)
    tagline = db.Column(db.String(120), nullable=False)
    Slug = db.Column(db.String(21), nullable=False)
    Context = db.Column(db.String(120), nullable=False)
    DAte = db.Column(db.DateTime, nullable=True, default=datetime.utcnow)
    img_file = db.Column(db.String(12), nullable=True)

@app.route("/")
def home():
    posts = Posts.query.filter_by().all()
    last=math.ceil(len(posts)/int(params['no_of_post']))
    #[0:params['no_of_post']]
    page=request.args.get('page')
    if(not str(page).isnumeric()):
        page = 1
    page = int(page)
    posts = posts[(page-1)*int(params['no_of_post']):(page-1)*int(params['no_of_post'])+ int(params['no_of_post'])]


    if(page==1):
        prev="#"
        next="/?page="+str(page+1)
    elif(page==last):
        prev="/?page="+str(page-1)
        next="#"
    else:
        prev = "/?page="+ str(page-1)
        next = "/?page="+ str(page+1)
    return render_template('index.html', params=params, posts=posts,prev=prev,next=next)

@app.route("/post/<string:post_slug>", methods=['GET'])
def post_route(post_slug):
     post = Posts.query.filter_by(Slug=post_slug).first()
     return render_template('post.html', params=params, post=post)

@app.route("/about")
def about():
    return render_template('about.html', params=params)

@app.route("/dashboard", methods=['GET', 'POST'])
def dashboard():
    if 'user' in session and session['user'] == params['admin_user']:
         posts=Posts.query.all()
         return render_template("dashboard.html", params=params,posts=posts)

    if request.method == 'POST':
        username = request.form.get('uname')
        userpass = request.form.get('upass')

        if username == params['admin_user'] and userpass  == params['admin_password']:
            session['user'] = username
            posts=Posts.query.all()
            return render_template("dashboard.html", params=params,posts=posts)


    return render_template('login.html', params=params)

@app.route("/contact", methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name1 = request.form.get('name')
        email1 = request.form.get('email')
        phone1 = request.form.get('phone')
        message1 = request.form.get('message')

        entry = Contacts(name=name1, email=email1, phone_number=phone1, message=message1)
        db.session.add(entry)
        db.session.commit()
        mail.send_message('New message from ' + name1,
                          sender=email1,
                          recipients=[params['user_name']],
                          body=message1 + "\n" + phone1
                          )
    return render_template('contact.html', params=params)

@app.route("/edit/<string:SN0>", methods=['GET', 'POST'])
def edit(SN0):
    if 'user' in session and session['user'] == params['admin_user']:
        if request.method=='POST':
            box_title=request.form.get('Title')
            tagline=request.form.get('tagline')
            Slug=request.form.get('Slug')
            Context=request.form.get('Context')
            img_file=request.form.get('img_file')
            DAte=datetime.now()
            if SN0=='0':
                post=Posts(Title=box_title, tagline=tagline,Slug=Slug,Context=Context,img_file=img_file,DAte=DAte)
                print(tagline)
                db.session.add(post)
                db.session.commit()
            else:
                post=Posts.query.filter_by(SN0=SN0).first()
                post.Title=box_title
                post.Slug=Slug
                post.Context=Context
                post.img_file=img_file
                post.DAte=DAte
                db.session.commit()
                return redirect("/edit/"+SN0)
        post=Posts.query.filter_by(SN0=SN0).first()
        return render_template('edit.html',params=params,post=post)

@app.route("/uploader", methods=['GET', 'POST'])
def uploader():

    if 'user' in session and session['user'] == params['admin_user']:
        if request.method == 'POST':
            f=request.files['file1']
            f.save(os.path.join(app.config["UPLOAD_FOLDER"],secure_filename(f.filename)))

            return "upload successfully"


@app.route("/logout")
def logout():
    session.pop('user')
    return redirect("/dashboard")


@app.route("/delete/<string:SN0>", methods=['GET', 'POST'])
def delete(SN0):
    if 'user' in session and session['user'] == params['admin_user']:
        post=Posts.query.filter_by(SN0=SN0).first()
        db.session.delete(post)
        db.session.commit()

    return redirect("/dashboard")
app.run(debug=True)
